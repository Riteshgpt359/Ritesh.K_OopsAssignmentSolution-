package com.gl.OopsLab1;

// Parent class
public class SuperDepartment {

	public String deparmentName() {
		return "Super Deparment";
	}

	public String getTodaysWork() {
		return "No Work as of now";
	}

	public String getWorkDeadline() {
		return "Nil";
	}

	public String isTodayAHoliday() {
		return "Today is not a Holiday";
	}
}
